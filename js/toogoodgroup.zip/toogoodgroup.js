﻿// Scrolls to the selected menu item on the page
$(function () {
	$('a[href*=#]:not([href=#],[data-toggle],[data-target],[data-slide])').click(function () {
		if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') || location.hostname == this.hostname) {
			var target = $(this.hash);
			target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
			if (target.length) {
				$('html,body').animate({
					scrollTop: target.offset().top
				}, 1000);
				return false;
			}
		}
	});
});
//#to-top button appears after scrolling
var fixed = false;
$(document).scroll(function () {
	if ($(this).scrollTop() > 250) {
		if (!fixed) {
			fixed = true;
			// $('#to-top').css({position:'fixed', display:'block'});
			$('#to-top').show("slow", function () {
				$('#to-top').css({
					position: 'fixed',
					display: 'block'
				});
			});
		}
	} else {
		if (fixed) {
			fixed = false;
			$('#to-top').hide("slow", function () {
				$('#to-top').css({
					display: 'none'
				});
			});
		}
	}
});
// Disable Google Maps scrolling
// See http://stackoverflow.com/a/25904582/1607849
// Disable scroll zooming and bind back the click event
var onMapMouseleaveHandler = function (event) {
	var that = $(this);
	that.on('click', onMapClickHandler);
	that.off('mouseleave', onMapMouseleaveHandler);
	that.find('iframe').css("pointer-events", "none");
}
var onMapClickHandler = function (event) {
	var that = $(this);
	// Disable the click handler until the user leaves the map area
	that.off('click', onMapClickHandler);
	// Enable scrolling zoom
	that.find('iframe').css("pointer-events", "auto");
	// Handle the mouse leave event
	that.on('mouseleave', onMapMouseleaveHandler);
}
// Enable map zooming with mouse scroll when the user clicks the map
$('.map').on('click', onMapClickHandler);

//Preloder script
jQuery(window).load(function () {
	'use strict';

	// Slider Height
	var slideHeight = $(window).height();
	$('#home .carousel-inner .item, #home .video-container').css('height', slideHeight);

	$(window).resize(function () {
		'use strict',
			$('#home .carousel-inner .item, #home .video-container').css('height', slideHeight);
	});

});


jQuery(function ($) {
	'use strict',


	// all Parallax Section
		//$(window).load(function () {
		//	'use strict',
			//$("#services").parallax("50%", 0.3);
			//$("#clients").parallax("50%", 0.3);
		//});

	// portfolio filter
	$(window).load(function () {
		'use strict',
			$portfolio_selectors = $('.portfolio-filter >li>a');
		if ($portfolio_selectors != 'undefined') {
			$portfolio = $('.portfolio-items');
			//$portfolio.isotope({
			//	itemSelector: '.col-sm-3',
			//	layoutMode: 'fitRows'
			//});

			$portfolio_selectors.on('click', function () {
				$portfolio_selectors.removeClass('active');
				$(this).addClass('active');
				var selector = $(this).attr('data-filter');
				$portfolio.isotope({ filter: selector });
				return false;
			});
		}
	});

	//Pretty Photo
	$("a[data-gallery^='prettyPhoto']").prettyPhoto({
		social_tools: false
	});


	// Contact form validation
	var form = $('.contact-form');
	form.submit(function () {
		'use strict',
			$this = $(this);
		$.post($(this).attr('action'), function (data) {
			$this.prev().text(data.message).fadeIn().delay(3000).fadeOut();
		}, 'json');
		return false;
	});


	// Navigation Scroll
	$(window).scroll(function (event) {
		Scroll();
	});

	$('.navbar-collapse ul li a').click(function () {
		$('html, body').animate({ scrollTop: $(this.hash).offset().top - 79 }, 1000);
		return false;
	});

});

// Preloder script
jQuery(window).load(function () {
	'use strict';
	$(".preloader").delay(1600).fadeOut("slow").remove();
});

//Preloder script
jQuery(window).load(function () {
	'use strict';

	// Slider Height
	var slideHeight = $(window).height();
	$('#home .carousel-inner .item, #home .video-container').css('height', slideHeight);

	$(window).resize(function () {
		'use strict',
			$('#home .carousel-inner .item, #home .video-container').css('height', slideHeight);
	});

});


// User define function
function Scroll() {
	var contentTop = [];
	var contentBottom = [];
	var winTop = $(window).scrollTop();
	var rangeTop = 200;
	var rangeBottom = 500;
	$('.navbar-collapse').find('.scroll a').each(function () {
		contentTop.push($($(this).attr('href')).offset().top);
		contentBottom.push($($(this).attr('href')).offset().top + $($(this).attr('href')).height());
	})
	$.each(contentTop, function (i) {
		if (winTop > contentTop[i] - rangeTop) {
			$('.navbar-collapse li.scroll')
			.removeClass('active')
			.eq(i).addClass('active');
		}
	})

};


// Skill bar Function
jQuery(document).ready(function () {
	jQuery('.skillbar').each(function () {
		jQuery(this).find('.skillbar-bar').animate({
			width: jQuery(this).attr('data-percent')
		}, 6000);
	});
});

